package APISK11Practice;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;

public class HandlingMockJsonTestcase {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(JsonResponsePayload.mockJsonResponse());
		
		//// Print No of courses returned by API

		
	int courseCount=	js.get("courses.size()");
	
	System.out.println("Total number of courses are  "+courseCount);
	
	////Print Purchase Amount

	int purchaseAmount= js.getInt("dashboard.purchaseAmount");
	System.out.println("Total purchase amount is  "+purchaseAmount);
	
	///Print Title of the first course

	
	String courseTitle=js.getString("courses[0].title");
	System.out.println("Title of first course is  "+courseTitle);
	
	// Print All course titles and their respective Prices

	System.out.println("Course title and their respective prices are\n");
	
	for(int i=0;i<courseCount;i++)
	{
	
		
		String title=  js.getString("courses["+i+"].title ");
		int price= js.getInt("courses["+i+"].price");
		
		System.out.println(title+"   "+price);
		
		
	}
	
	
	////Print no of copies sold by RPA Course
	
	
	for(int i=0;i<courseCount;i++)
	{
		String title=  js.getString("courses["+i+"].title ");
		if(title.equalsIgnoreCase("RPA"))
		{
			int copies=js.getInt("courses["+i+"].copies");
			System.out.println("No of copies sold by RPA is  "+copies);
			
		}
		
		
	}
	
	
	//// Verify if Sum of all Course prices matches with Purchase Amount

	int sum=0;
	
	for(int i=0;i<courseCount;i++)
	{
	
		
		int copies=  js.getInt("courses["+i+"].copies ");
		int price= js.getInt("courses["+i+"].price");
		int amount= copies*price;
		
		sum=sum+amount;
		
		
		
		
		
	}
	
	System.out.println("Total sum is  "+sum);
	
	Assert.assertEquals(purchaseAmount, sum);
	
	System.out.println("All test cases passed");
	
	
		
		
		
		

	}

}
