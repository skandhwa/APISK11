package APISK11Practice;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import io.restassured.RestAssured;

public class HandlingStaticPayload {

	public static void main(String[] args) throws IOException {
		
		
		RestAssured.baseURI="https://reqres.in";
		
		String response=	given().log().all().headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
			.headers("content-type","application/json").body
					
			(new String		(Files.readAllBytes(Paths.get("E:/TestData10thJan.txt"))
					
					
					
					)).
			
			
			when().post("api/users").
			
			
			
			then().log().all().assertThat().statusCode(201).extract().response().asString();
			
			System.out.println(response);
		

	}

}
