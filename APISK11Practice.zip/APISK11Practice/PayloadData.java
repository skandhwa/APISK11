package APISK11Practice;

public class PayloadData {
	
	public static String getData(String bookName, String isbn, int aisle,String author)
	
	{
		String payload ="\"name\":\""+bookName+"\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\""+author+"\"\r\n"
				+ "";
		
		return payload;
		
	}
	
	

}
