package APISK11Practice;

import java.util.LinkedHashMap;
import java.util.Map;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class UsingMapToPassPayload {

	public static void main(String[] args) {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		
		mp.put("name","harry");
		mp.put("job","Qa Manager");
		mp.put("salary",90000);
		mp.put("isMarried",true);
		
		
		RestAssured.baseURI="https://reqres.in";
		
	String response=	given().log().all().headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.headers("content-type","application/json").body(mp).
		
		
		when().post("api/users").
		
		
		
		then().log().all().assertThat().statusCode(201).extract().response().asString();
		
		System.out.println(response);
		

	}

}
