package APISK11Practice;

import static io.restassured.RestAssured.given;

import java.net.http.HttpConnectTimeoutException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UsingTestNgDP {
	
	@DataProvider(name="BooksData")

	public Object [][] method()
	{

	return  new Object [][] 

	{

		{"Automation with selenium","rfed",897,"John mczienze"},
		{"Automation with Playwright","uytr",197,"harry mczienze"}


	};
	


	}
	
	@Test(dataProvider="BooksData")
	public void getBooksData(String bookname,String isbn,int aisle,String author) throws HttpConnectTimeoutException
	{
		
		RestAssured.baseURI="http://216.10.245.166";
		
	Response res=	given().log().all().headers("content-type","application/json")
		.body(PayloadData.getData(bookname, isbn, aisle, author)).
		
		
		when().post("Library/Addbook.php").
		
		
		then().log().all().assertThat().statusCode(200).extract()
		.response();
	
	long time=res.getTime();
	if(time>5000)
	{
		throw new HttpConnectTimeoutException("Taking longer than expected");
	}
	
	else
	{
		System.out.println("Within the threshold");
	}
	
	
	String response=  res.asString();
	
	System.out.println(response);
		
		
		
	}
	
	
	
	
	
	
	
	
	

}
