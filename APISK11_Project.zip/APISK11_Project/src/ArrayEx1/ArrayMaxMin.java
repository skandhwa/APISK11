package ArrayEx1;

class P10
{
	public static int getLargestSmallest(int []a,int total)
	{
		for(int i=0;i<a.length;i++)//i=2,1<5
		{
			for(int j=i+1;j<a.length;j++)//j=3,5<5
			{
				if(a[i]>a[j])///a[1]>a[4]
				{
					int t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		}
		
		return a[total-3];
	}
}


public class ArrayMaxMin {

	public static void main(String[] args) {
		
		int []a= {3,1,7,6,0};
		
		int len=a.length;
		
	System.out.println(P10.getLargestSmallest(a, len));	
		
		
		
		

	}

}
