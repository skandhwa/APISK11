package ArrayEx1;

import java.util.Arrays;

public class ArrayMethods {

	public static void main(String[] args) {
		
		int []a= {13,5,16,3,9};
		
		int []b= {12,5,36,3,9};
		
//	boolean flag=	Arrays.equals(a,b);
//	
//	System.out.println(flag);
	
	int x=Arrays.compare(b, a);
	
	System.out.println(x);
	
	
	
	
	
		

	}

}
