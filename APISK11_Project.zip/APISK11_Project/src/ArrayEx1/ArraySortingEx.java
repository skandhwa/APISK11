package ArrayEx1;

public class ArraySortingEx {

	public static void main(String[] args) {
		
		int []a= {3,1,7,6,0};
		
		for(int i=0;i<a.length;i++)//i=2,1<5
		{
			for(int j=i+1;j<a.length;j++)//j=3,5<5
			{
				if(a[i]>a[j])///a[1]>a[4]
				{
					int t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		}
		
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		

	}

}
