package ArrayEx1;

public class MyPracticeArray1 {

	public static void main(String[] args) {
		
		int []a= {12,5,6,3,9};
		
		int x=a.length;
		
		System.out.println(x);
		
		for(int i=0;i<x;i++)///i=0,0<5//i=1,1<5//i=2,2<5//i=3,3<5//i=4,4<5
		{
			System.out.println(a[i]);//a[0]//a[1]//a[2]//a[3]//a[4]
		}
		
		int []b=new int[] {34,12,89,99,102};
		
		int []c=new int[6];
		
		
		
		

		
		
		

	}

}
