package ArrayEx1;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		
		int []a= {4,7,8,2};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println("Sum is  "+sum);

	}

}
