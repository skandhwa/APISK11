package CollectionsPractice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(99);
		
		for(int x:li)
		{
			System.out.println(x);
		}
		
		System.out.println("######################################################");
		Iterator itr=li.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("######################################################");
		for(int i=0;i<li.size();i++)
		{
			System.out.println(li.get(i));
		}
		
		
		

	}

}
