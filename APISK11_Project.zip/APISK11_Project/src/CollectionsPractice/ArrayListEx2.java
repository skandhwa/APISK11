package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx2 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(23);
		li.add("Saurabh");
		li.add('A');
		li.add(true);
		li.add(89066.56f);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
