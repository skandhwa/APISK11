package ExceptionHandlingExample;

public class FinalExceptionHandling {

	public static void main(String[] args) {
		
		try
		{
		int a=9/3;
		System.out.println(a);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Caught with "+e.getMessage());
		}
		
		
		finally
		{
			System.out.println("I will always execute");
		}
		
		
		int x=10,y=20;
		int z=x+y;
		System.out.println(z);
		
		
		
		

	}

}
