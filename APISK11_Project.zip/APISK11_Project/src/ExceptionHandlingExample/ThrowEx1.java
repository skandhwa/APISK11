package ExceptionHandlingExample;

class Vote
{
	public static void getVote(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("Age is less than 18 years");
		}
		else
		{
			System.out.println("Perosn is elligible to vote");
		}
	}
}




public class ThrowEx1 {

	public static void main(String[] args) {
		
		Vote.getVote(13);
		

	}

}
