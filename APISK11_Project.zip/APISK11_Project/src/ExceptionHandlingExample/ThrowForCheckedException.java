package ExceptionHandlingExample;

import java.io.FileNotFoundException;

class FileAccess
{
	public static void getFileAccess(int empId) throws FileNotFoundException
	{
		if(empId!=78965)
		{
			throw new FileNotFoundException("You dont have permission to access this file");
		}
		else 
		{
			System.out.println("You have gained access to file,you can perform CRUD operations on file");
		}
	}
}



public class ThrowForCheckedException {

	public static void main(String[] args) throws FileNotFoundException {
		
		FileAccess.getFileAccess(76965);
		

	}

}
