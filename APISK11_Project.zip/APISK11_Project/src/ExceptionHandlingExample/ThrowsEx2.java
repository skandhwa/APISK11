package ExceptionHandlingExample;

public class ThrowsEx2 {

	public static void main(String[] args) throws InterruptedException {
		
		Thread.sleep(5000);
		

	}

}
