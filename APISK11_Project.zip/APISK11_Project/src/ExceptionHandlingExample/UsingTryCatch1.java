package ExceptionHandlingExample;

public class UsingTryCatch1 {

	public static void main(String[] args) {
		
		try
		{
		int x=9/0;
		System.out.println(x);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Caught with  "+e);
		}
		
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		
		

	}

}
