package ExceptionHandlingExample;

public class UsingTryCatch2 {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		
		int x=str.length();
		
		System.out.println("Length of String is  "+x);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("Caught with  "+e);
		}
		
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		

	}

}
