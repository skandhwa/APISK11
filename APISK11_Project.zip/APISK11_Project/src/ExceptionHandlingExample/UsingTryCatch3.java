package ExceptionHandlingExample;

public class UsingTryCatch3 {

	public static void main(String[] args) {
		
		try
		{
		int []x= {23,45,67,88,99};
		
		System.out.println(x[8]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Caught with  "+e);
		}
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		
		
		
		
		
	}

}
