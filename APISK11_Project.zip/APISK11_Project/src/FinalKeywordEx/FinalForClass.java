package FinalKeywordEx;

final class Y1
{
	public void display()
	{
		System.out.println("Hello");
	}
}

class Y9 extends Y1
{
	public void test()
	{
		System.out.println("Hi");
	}
}



public class FinalForClass {

	public static void main(String[] args) {
		

	}

}
