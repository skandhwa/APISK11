package FinalKeywordEx;

class J
{
	final int sum(int x,int y)
	{
		return x+y;
	}
}

class K extends J
{
	int sum(int x,int y)
	{
		return x+y;
	}
}



public class FinalForMethod {

	public static void main(String[] args) {
		

	}

}
