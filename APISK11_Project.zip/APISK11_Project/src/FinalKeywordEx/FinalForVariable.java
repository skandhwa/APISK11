package FinalKeywordEx;

class M1
{
	final int x=20;
	void display()
	{
		x=30;
		final int y=40;
		System.out.println(x);
	}
	
}



public class FinalForVariable {

	public static void main(String[] args) {
		
		M1 obj=new M1();
		obj.display();
	System.out.println(obj.x);
		
		

	}

}
