package JavaBasics;

class Y4
{
	int sum(int x,int y)
	{
		return x+y;
	}
}

class Y6 extends Y4
{
	int diff(int x,int y)
	{
		return x-y;
	}
}



public class InheritanceEx1 {

	public static void main(String[] args) {
		
		Y6 obj=new Y6();
	System.out.println(obj.sum(23, 67));	
	System.out.println	(obj.diff(12, 4));

	}

}
