package JavaBasics;

class Y2
{
	void display()
	{
		System.out.println("Hello");
	}
}



public class MethodsEx1 {

	public static void main(String[] args) {
		
		Y2 obj=new Y2();
		obj.display();
		

	}

}
