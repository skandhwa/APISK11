package JavaBasics;

class Y3
{
	int sum()
	{
		int a=20,b=30;
		int res=a+b;
		System.out.println(res);
		return res;
	}
}

public class MethodsEx2 {

	public static void main(String[] args) {
		
		Y3 obj=new Y3();
	obj.sum();	
		

	}

}
