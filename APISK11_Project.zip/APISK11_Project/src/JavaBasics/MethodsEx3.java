package JavaBasics;

class Y5
{
	public double sum(int x,int y)
	{
		return x+y;
	}
}

public class MethodsEx3 {

	public static void main(String[] args) {
		
		Y5 obj=new Y5();
	System.out.println(obj.sum(15, 20));	
		

	}

}
