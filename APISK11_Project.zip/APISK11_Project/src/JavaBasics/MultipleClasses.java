package JavaBasics;

class X
{
	X()
	{
		System.out.println("hey");
	}
	
	
	void test()
	{
		System.out.println("Hello");
	}
}


class Y 
{
	void display()
	{
		System.out.println("Hi");
	}
}



public class MultipleClasses {

	public static void main(String[] args) {
		
		X obj=new X();
		obj.test();
		
		Y obj1=new Y();
		obj1.display();
		
		

	}

}
