package JavaBasics;

class Y1
{
	int id;
	String name;
	double salary;
	
	
	
	Y1(int j,String m)
	{
		id=j;
		name=m;
	}
	
	
	
	
	Y1(int i, String n,double s)
	{
		id=i;
		name=n;
		salary=s;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
	
}



public class ParameterizedConstructorEx {

	public static void main(String[] args) {
		
		Y1 obj=new Y1(1234,"Harry",80000);
		obj.display();
		
		Y1 obj1=new Y1(4567,"John");
		obj1.display();
		
		
		
		

	}

}
