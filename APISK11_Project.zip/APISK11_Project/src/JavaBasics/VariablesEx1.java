package JavaBasics;

class A
{
	int x=30;
	
	void display()
	{
		int a=20;
		
		int y=x+a;
		System.out.println(y);
	}
	
	void test()
	{
		int b=a+30;
		System.out.println(b);
	}
}




public class VariablesEx1 {

	public static void main(String[] args) {
		

	}

}
