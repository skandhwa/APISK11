package OperatorsEx;

public class LogicalOperator {

	public static void main(String[] args) {
		
		int a=10,b=5,c=12;
		
		System.out.println(a!=b);
		
		if(a<b || c>b)
		{
			System.out.println("Yes");
		}
		else
		{
			System.out.println("No");
		}
		

	}

}
