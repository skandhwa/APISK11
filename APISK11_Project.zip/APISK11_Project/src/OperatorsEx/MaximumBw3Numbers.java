package OperatorsEx;

public class MaximumBw3Numbers {

	public static void main(String[] args) {
	
		int a=10,b=20,c=30;
		
		
		int max= (a>b ? (a>c?a:c ) : (b>c?b:c)   );
		
		System.out.println(max);
		
		
		int x=30;
		
		x+=20;//x=x+20
		
		System.out.println(x);
		
		x/=2;// x=x/2
		
		System.out.println(x);
		
		x*=5;// x=x*5
		
		
		
		
		

	}

}
