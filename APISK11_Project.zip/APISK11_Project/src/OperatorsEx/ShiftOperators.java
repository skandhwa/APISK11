package OperatorsEx;

public class ShiftOperators {

	public static void main(String[] args) {
		
		
         System.out.println(10<<4);	
         
         System.out.println(12<<3);
         
         
         System.out.println(120>>2);  
         
         System.out.println(160>>3);

	}

}
