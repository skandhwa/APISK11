package OperatorsEx;

public class TernaryOperatorEx {

	public static void main(String[] args) {
		
		
		
		//// condition ? firstCalculation:Secondcalculation
		
		int a=20,b=30,max;
		
		max= (a>b ?a:b );
		
		System.out.println("Maximum is  "+max);
		

	}

}
