package OperatorsEx;

public class UnaryOp {

	public static void main(String[] args) {
		
		int a=5;
		
//		int x=++a;
//		
//		System.out.println(x);
		
		int b=10;
		
		int r= a++ + ++b;  /// 
		
		System.out.println(r);
		
		
		/// --a   a++   ++a
		

	}

}
