package PolyMorphismEx;

class P1
{
	 static int sum(int x,int y,int z)
	{
		return x+y+z;
	}
	
	 static float sum(int x,int y,float z)
	{
		return x+y+z;
	}
	
	 static int sum(int a,int b)
	{
		return a+b;
	}
}



public class MethodOverloading1 {

	public static void main(String[] args) {
		
		P1 obj=new P1();
//	System.out.println(obj.sum(12, 54,89));	
//	
//	System.out.println(obj.sum(67, 76));
		
		System.out.println(	P1.sum(34, 67));
		
		

	}

}
