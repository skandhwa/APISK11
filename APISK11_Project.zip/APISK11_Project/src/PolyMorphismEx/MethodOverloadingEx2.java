package PolyMorphismEx;

public class MethodOverloadingEx2 {
	
	public static void main(String str)
	{
		System.out.println(str.length());
	}
	
	

	public static void main(String[] args) 
	{
		
		System.out.println("Hello");
		MethodOverloadingEx2.main("India");
		

	}

}
