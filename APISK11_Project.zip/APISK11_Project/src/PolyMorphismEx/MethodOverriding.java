package PolyMorphismEx;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class Axis extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}




public class MethodOverriding {

	public static void main(String[] args) {
		
		Axis obj=new Axis();
	System.out.println(obj.getROI(3, 4));	
		
		Bank obj1=new Bank();
		System.out.println	(obj1.getROI(4, 5));
		
//		Bank b=new SBI();
//		b.getROI(2, 2);
		

	}

}
