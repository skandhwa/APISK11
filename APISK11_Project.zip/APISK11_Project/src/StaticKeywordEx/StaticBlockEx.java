package StaticKeywordEx;

public class StaticBlockEx {
	
	static 
	{
		System.out.println("I will execute first");
	}
	

	public static void main(String[] args) {
		
		System.out.println("Java Rest Assured");
		

	}

}
