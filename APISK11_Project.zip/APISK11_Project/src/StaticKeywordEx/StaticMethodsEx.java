package StaticKeywordEx;

class Z1
{
	static int sum(int x,int y)
	{
		return x+y;
	}
}

public class StaticMethodsEx {

	public static void main(String[] args) {
		
	System.out.println(Z1.sum(23, 78));
		

	}

}
