package StaticKeywordEx;

class Emp
{
	int id;
	String ename;
	static String comName="TCS";
	static String comAdd="Mumbai";
	
	Emp(int i,String e)
	{
		id=i;
		ename=e;
		
	}
	
	void display()
	{
		System.out.println(id+"  "+ename+"  "+comName+"  "+comAdd);
	}
	
}


public class StaticVariableEx {

	public static void main(String[] args) {
		
		Emp obj=new Emp(123,"Harry");
		Emp obj1=new Emp(723,"Tom");
		Emp obj2=new Emp(923,"Mike");
		Emp obj3=new Emp(423,"John");
		obj.display();
		obj1.display();
		obj2.display();
		obj3.display();
		
		
		
		

	}

}
