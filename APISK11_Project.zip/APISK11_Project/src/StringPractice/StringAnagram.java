package StringPractice;

import java.util.Arrays;

public class StringAnagram {

	public static void main(String[] args) {
		
		String str1="brag";
		
		String str2="Grab";
		
		str1=str1.toLowerCase();
		str2=str2.toLowerCase();
		
		if(str1.length()!=str2.length())
		{
			System.out.println("Not Anagram");
		}
		
		else
		{
			char ch1[]= str1.toCharArray();
			char ch2[]=str2.toCharArray();
			
			Arrays.sort(ch1);
			Arrays.sort(ch2);
			
		boolean flag=	Arrays.equals(ch1,ch2);
		
		if(flag==true)
		{
			System.out.println("Both are anagram");
		}
		
		else
		{
			System.out.println("Not anagram");
		}
			
			
		}
		

	}

}
