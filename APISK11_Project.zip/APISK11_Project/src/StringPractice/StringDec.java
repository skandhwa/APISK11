package StringPractice;

public class StringDec {

	public static void main(String[] args) {
		
		String str="Harry";
		
	str=	str.concat("Dscouza");
		
		System.out.println(str);
		
		//String declaration by literal
		
		String str2="Harry";
		
		String str1=new String("Tom");//By using new Keyword
		
		
		

	}

}
