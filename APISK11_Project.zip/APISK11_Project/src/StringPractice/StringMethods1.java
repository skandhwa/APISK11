package StringPractice;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="Welcome";
		
	char ch=	str.charAt(2);
	
	System.out.println(ch);
		

	}

}
