package StringPractice;

public class StringMethods2 {

	public static void main(String[] args) {
		
//		String str="Republic";
//		
//	String str1=	str.substring(2,7);
//	
//	System.out.println(str1);
		
		String str="Seleniuem";
		
	int x=	str.indexOf("e",4);
	
	System.out.println("Index of e is "+x);
		
		

	}

}
