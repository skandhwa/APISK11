package StringPractice;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="tip tap@toe@tollfree";
		
		String s1[]= str.split("@");
		
	    for(String x:s1)
	    {
	    	System.out.println(x);
	    }
		
		

	}

}
