package StringPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
//		String str="domain";
//		
//	char[]ch=	str.toCharArray();
//		
//		for(char x:ch)
//		{
//			System.out.println(x);
//		}
		
		String str="java playwright";
		
	//str=	str.replace('a', 'b');
	
	str=str.replaceAll("playwright", "selenium");
		
		System.out.println(str);
		

	}

}
