package StringPractice;

public class StringMethods5 {

	public static void main(String[] args) {
//		
//		String str="@#%^&1234ABCDabcd";
//		
//		str = str.replaceAll("[^a-z]", "");
//		
//		System.out.println(str);
		
		String str=" ab   cd  ";
		
	str=	str.trim();
	
	System.out.println(str);
		

	}

}
