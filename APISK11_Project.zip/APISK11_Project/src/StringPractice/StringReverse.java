package StringPractice;

public class StringReverse {

	public static void main(String[] args) {
		
		String str="Java";
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)//i=4,4>=0//i=3,3>=0//i=2,2>=0//i=1,1>=0
		{
			revstr=revstr+str.charAt(i);// avaJ
		}
		
		
		System.out.println(revstr);

	}

}
