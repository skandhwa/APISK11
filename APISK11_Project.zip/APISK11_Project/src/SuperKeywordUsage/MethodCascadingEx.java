package SuperKeywordUsage;

class Z1
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		display();
		test();
		
	}
}


public class MethodCascadingEx {

	public static void main(String[] args) {
		
		Z1 obj=new Z1();
		obj.message();
		

	}

}
