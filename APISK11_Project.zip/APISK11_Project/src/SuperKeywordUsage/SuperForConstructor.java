package SuperKeywordUsage;

class Y7
{
	int id;
	String name;
	
	Y7(int i,String n)
	{
		id=i;
		name=n;
	}
	
	void display()
	{
		
	}
}

class Y8 extends Y7
{
	Y8()
	{
		super(12,"Saurabh");
		System.out.println("Hi");
		
	}
}


public class SuperForConstructor {

	public static void main(String[] args) {
		
		Y8 obj=new Y8();
		
		

	}

}
