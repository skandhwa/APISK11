package SuperKeywordUsage;

class Mammall
{
	void eat()
	{
		System.out.println("All mammals eat");
	}
}

class Animals extends Mammall
{
	void sleep()
	{
		System.out.println("All Animals sleep");
	}
	
	void bark()
	{
		System.out.println("All animals bark");
	}
	
	void eat()
	{
		System.out.println("All animals eat");
	}
	
	void display()
	{
		sleep();
		bark();
		eat();
		super.eat();
	}
}


public class SuperForMethod {

	public static void main(String[] args) {
		
		Animals obj=new Animals();
		obj.display();
		

	}

}
