package SuperKeywordUsage;

class Mammal
{
	String colour="white";
}


class Animal
{
	String colour="black";
}

class Dog extends Animal
{
	String colour="red";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
}



public class SuperVariableEx {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		obj.display();
		

	}

}
