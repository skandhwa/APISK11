package ThisKeyword;

class C1
{
	int id;
	String name;
	double salary;
	
	C1(int id,String name,double salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
}


public class ThisEx1 {

	public static void main(String[] args) {
		
		C1 obj=new C1(1234,"Harry",80000);
		obj.display();
		

	}

}
