package ThisKeyword;

class C3
{
	int id;
	String name;
	float salary;
	
	C3(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	C3(int id,String name,float salary)
	{
		this(id,name);
		this.salary=salary;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+" "+salary);
	}
	
	
}



public class ThisEx2 {

	public static void main(String[] args) {
		
		C3 obj=new C3(1234,"Harry");
		obj.display();
		
		C3 obj1=new C3(7865,"John",90000);
		obj1.display();
		
		

	}

}
