package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods1 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("Orange");
		li.add("mango");
		li.add("kiwi");
		li.add("banana");
		
		
		List<String> fruits= List.of("Orange","Mango","Apple","banana");
		
		System.out.println(fruits);
		
	boolean flag=	li.contains("Orange");
	
	System.out.println("DOes the list contains ornage " +flag);
	
	li.add(3,"pines");
	
	System.out.println(li);
		
		
		
		
		
		
		
	}

}
