package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("Orange");
		li.add("mango");
		li.add("kiwi");
		li.add("banana");
		li.add("coconut");
		
		
		List<String> li2=new ArrayList<String>();
		li2.add("coconut");
		li2.add("melon");
		li2.add("apple");
		li2.add("banana");
		
//		li.addAll(li2);
//		
//		System.out.println(li);
		
	boolean flag1=	li.containsAll(li2);
	
	System.out.println("Does the second list contains all element of first list "+flag1);
		
	boolean flag3=	li.equals(li2);
	
	System.out.println(flag3);
		
		
		
		

	}

}
