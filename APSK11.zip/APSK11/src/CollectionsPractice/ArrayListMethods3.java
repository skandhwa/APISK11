package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods3 {

	public static void main(String[] args) {
		List<String> li=new ArrayList<String>();
		li.add("Orange");
		li.add("mango");
		li.add("kiwi");
		li.add("banana");
		li.add("coconut");
		
//		int x=li.size();
//		System.out.println("Size is  "+x);
//		
//		li.remove("kiwi");
//		li.remove(3);
//		
//		System.out.println(li);
		
		List<String> li2=new ArrayList<String>();
		li2.add("coconut");
		li2.add("melon");
		li2.add("apple");
		li2.add("banana");
		
		
		li.removeAll(li2);
		
		System.out.println(li);
		
		li.clear();
		
		System.out.println(li);

	}

}
