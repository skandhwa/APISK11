package CollectionsPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class ArrayListMethods4 {

	public static void main(String[] args) {
		
		String []arr= {"Apple","Mango","Orange"};
		
		List<String> li=new ArrayList<>(Arrays.asList(arr));
		
		
		
		

	}

}
