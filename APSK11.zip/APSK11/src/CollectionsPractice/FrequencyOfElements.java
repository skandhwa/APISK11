package CollectionsPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfElements {

	public static void main(String[] args) {
		
		int []a= {10,20,10,30,20,10};
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1)); /// mp.put(10, 1+1 )
			}
			
			else
			{
				mp.put(x,1);
			}
			
			
		}
		
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		
		int maxElement=0;
		int minElement=0;
		
		int maxFreq=0;
		int minFreq=9999;
		
	     for (Map.Entry<Integer, Integer> y : mp.entrySet()) {

	            if (y.getValue() > maxFreq) //1>3
	            {
	                maxFreq = y.getValue();///maxFreq=3
	                maxElement = y.getKey();///maxElement=10
	            }

	            if (y.getValue() < minFreq) ///1<2
	            {
	                minFreq = y.getValue();//minfreq=1
	                minElement = y.getKey();///minElement=30
	            }
	        }

	        System.out.print("Maximum Frequency Element: " + maxElement);
	        System.out.println("Maximum Frequency: " + maxFreq);
	        
	        System.out.println("###################################################");

	        System.out.print("Minimum Frequency Element: " + minElement);
	        System.out.println("Minimum Frequency: " + minFreq);
		
		
		
		
		

	}

}
