package CollectionsPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfString {

	public static void main(String[] args) {
	
		String str="madamm";
		
		char []ch=str.toCharArray();
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		for(char x:ch)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		
		char maxElement=0;
		char minElement=0;
		
		int maxFreq=0;
		int minFreq=9999;
		
	     for (Map.Entry<Character, Integer> y : mp.entrySet()) {

	            if (y.getValue() > maxFreq) //1>3
	            {
	                maxFreq = y.getValue();///maxFreq=3
	                maxElement = y.getKey();///maxElement=10
	            }

	            if (y.getValue() < minFreq) ///1<2
	            {
	                minFreq = y.getValue();//minfreq=1
	                minElement = y.getKey();///minElement=30
	            }
	        }

	        System.out.print("Maximum Frequency Element:   " + maxElement +"  ");
	        System.out.println("Maximum Frequency: " + maxFreq);
	        
	        System.out.println("###################################################");

	        System.out.print("Minimum Frequency Element:   " + minElement+"  ");
	        System.out.println("Minimum Frequency: " + minFreq);
		
		
		
		
		
		
		

	}

}
