package CollectionsPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class HashSetEx1 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		s1.add(23);
		s1.add(45);
		s1.add(98);
		s1.add(104);
		
		for(Integer x:s1)
		{
			System.out.println(x);
		}
		
		

	}

}
