package CollectionsPractice;

import java.util.LinkedList;
import java.util.List;

public class LinkedListEx {

	public static void main(String[] args) {
		
		List<String> li=new LinkedList<String>();
		li.add("mango");
		li.add("orange");
		li.add("banana");
		li.add("pines");
		
		System.out.println(li);
		
		
		

	}

}
