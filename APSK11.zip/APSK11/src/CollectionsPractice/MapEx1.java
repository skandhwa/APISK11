package CollectionsPractice;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(12,"Apple");
		mp.put(4,"Orange");
		mp.put(2,"Mango");
		mp.put(32,"Kiwi");
		
		System.out.println(mp);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
	boolean flag=	mp.containsKey(12);
	
	System.out.println("Does the map contains 12 "+flag);
	
	
	    String val=        mp.get(32);
	    
	    System.out.println("Getting value at key 32 "+val);
		
		
		

	}

}
