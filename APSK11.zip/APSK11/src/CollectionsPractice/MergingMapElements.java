package CollectionsPractice;

import java.util.HashMap;
import java.util.Map;

public class MergingMapElements {

	public static void main(String[] args) {
		
		Map<Integer,String> mp1=new HashMap<Integer,String>();
		mp1.put(12,"Apple");
		mp1.put(4,"Orange");
		mp1.put(2,"Mango");
		mp1.put(32,"Kiwi");
		
		
		Map<Integer,String> mp2=new HashMap<Integer,String>();
		mp2.put(42,"Melon");
		mp2.put(19,"Pines");
		mp2.put(22,"Mango");
		mp2.put(42,"Kiwi");
		
		mp1.putAll(mp2);
		
		
		System.out.println(mp1);
		
		
		
		
		
		
		
		

	}

}
