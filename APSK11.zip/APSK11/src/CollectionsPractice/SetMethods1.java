package CollectionsPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods1 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		s1.add(23);
		s1.add(23);
		s1.add(45);
		s1.add(98);
		s1.add(104);
		s1.add(null);
		s1.add(null);
		
	boolean flag=	s1.contains(45);
	
	System.out.println(flag);
	
	s1.remove(98);
	
	System.out.println(s1);
	

		

	}

}
