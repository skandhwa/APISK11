package CollectionsPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods2 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		s1.add(23);
		s1.add(45);
		s1.add(98);
		s1.add(104);
		
		
		Set<Integer> s2=new LinkedHashSet<Integer>();
		s2.add(63);
		s2.add(54);
		s2.add(98);
		s2.add(104);
		
		
//		s1.addAll(s2);
//		
//		System.out.println(s1);
//		
		
		
//		s1.retainAll(s2);
//		System.out.println(s1);
		
		
	boolean flag=	s1.containsAll(s2);
	
	System.out.println(flag);
	
	
	s1.removeAll(s2);
	
	System.out.println(s1);
	
	System.out.println("####################################");
	
	for(Integer x:s1)
	{
		System.out.println(x);
	}
	

	}

}
