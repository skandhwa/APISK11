package CollectionsPractice;

import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(23);
		stk.push(13);
		stk.push(44);
		stk.push(89);
		stk.pop();
		
		System.out.println(stk);
		
	System.out.println(stk.peek());	
	
	System.out.println(stk.lastElement());
		
		
		
		

	}

}
