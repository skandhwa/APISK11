package CollectionsPractice;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		Set<Object> s1=new TreeSet<Object>();
		s1.add(34);
		s1.add(78);
		s1.add(5);
		s1.add(9);
		s1.add(104);
		s1.add("Aman");
		s1.add(true);
		s1.add(78999.50f);
		
		for(Object x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		
	//System.out.println(s1.descendingSet());	
		
		
		
		
	}

}
