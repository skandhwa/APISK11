package CollectionsPractice;

import java.util.Map;
import java.util.TreeMap;

public class TreeapEx {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp1=new TreeMap<Integer,String>();
		
		mp1.put(92,"Apple");
		mp1.put(54,"Orange");
		mp1.put(12,"Mango");
		mp1.put(32,"Kiwi");
		
		for(Map.Entry x:mp1.entrySet())
		{
			System.out.println(x.getKey());
			System.out.println(x.getValue());
		}
		
		
		

	}

}
