package MyRestAssuredBasics;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class MyTest1 {

	public static void main(String[] args) {
		
		String ExpectedEmail="george.bluth@reqres.in";
		
		RestAssured.baseURI="https://reqres.in";
		
         String Response=	given().log().all().headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.headers("content-type","application/json").
		
		
		
		when().get("api/users").
		
		
		then().log().all().assertThat().statusCode(200).
		
		extract().response().asString();
         
         
         System.out.println(Response);
         
         
         JsonPath js=new JsonPath(Response);
         
      String actualEmail=   js.getString("data[0].email");
      
      System.out.println(actualEmail);
      
      Assert.assertEquals(ExpectedEmail, actualEmail);
         
      System.out.println("All assertions passed");
         
		
	String val=	js.getString("support.text");
	
	System.out.println(val);
		
		

	}

}
