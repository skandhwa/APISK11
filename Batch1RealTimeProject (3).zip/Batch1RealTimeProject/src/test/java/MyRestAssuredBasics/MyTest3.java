package MyRestAssuredBasics;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class MyTest3 {

	public static void main(String[] args) throws HttpTimeoutException {
		
RestAssured.baseURI="https://reqres.in";
		
         Response res=	given().log().all().headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.headers("content-type","application/json")
	  .body(PayloadData.getPayloadData("Harry","QA Manager")).
		
		
		when().post("api/users").
		
		
		then().log().all().assertThat().statusCode(201).headers("Content-Type","application/json; charset=utf-8").
		
		extract().response();
        
        
        System.out.println(res.asString());
        
        
      long time=  res.getTime();
      
      if(time>7000)
      {
    	  throw new HttpTimeoutException("Taking More than expected time");
      }
      
      else
      {
    	  System.out.println("Test Case passed");
      }
		
		
		

	}

}
