package MyRestAssuredBasics;

public class PayloadData {
	
	
	public static String getPayloadData(String val1,String val2)
	{
		String payload="{\r\n"
				+ "\r\n"
				+ "\"name\":\""+val1 +"\",\r\n"
				+ "\"job\":\"" +val2 +"\"\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "}";
		
		return payload;
		
		
		
	}
	
	

}
